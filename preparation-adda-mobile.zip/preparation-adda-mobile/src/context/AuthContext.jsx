import { createContext, useContext, useEffect, useState } from 'react';
import { loginUser, signupUser, logoutUser, getCurrentUser } from '../api/auth';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    getCurrentUser()
      .then(setUser)
      .finally(() => setIsLoading(false));
  }, []);

  async function login(email, password) {
    const { user: loggedInUser } = await loginUser({ email, password });
    setUser(loggedInUser);
    return loggedInUser;
  }

  async function signup(name, email, password) {
    const { user: newUser } = await signupUser({ name, email, password });
    setUser(newUser);
    return newUser;
  }

  async function logout() {
    await logoutUser();
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, isLoading, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
