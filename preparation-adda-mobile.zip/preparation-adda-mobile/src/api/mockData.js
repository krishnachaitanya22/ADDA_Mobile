// Shared mock dataset. In production this all comes from your database —
// this file is the only thing that "is" your DB until the backend exists.

export const mockUsers = [
  {
    id: 'u1',
    name: 'Aditi Sharma',
    email: 'aditi@example.com',
    password: 'password123',
    role: 'student',
    avatarColor: '#F59E0B',
  },
  {
    id: 'admin1',
    name: 'Rahul Mehta',
    email: 'admin@preparationadda.com',
    password: 'admin123',
    role: 'admin',
    avatarColor: '#1E1B4B',
  },
]

export const mockCategories = [
  'Mathematics',
  'Physics',
  'Computer Science',
  'English',
  'Chemistry',
  'Test Prep',
]

export const mockCourses = [
  {
    id: 'c1',
    title: 'Calculus I: Limits to Integrals',
    category: 'Mathematics',
    instructor: 'Dr. Priya Nair',
    price: 1499,
    rating: 4.8,
    reviewCount: 312,
    thumbnail: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=600&h=400&fit=crop',
    description:
      'Build real intuition for limits, derivatives, and integrals through worked problems, not just formulas. Designed for class 11–12 and first-year college students.',
    level: 'Intermediate',
    totalDuration: '8h 20m',
    lessons: [
      { id: 'l1', title: 'What is a Limit, Really?', duration: '12:40', youtubeId: 'dQw4w9WgXcQ', isPreview: true },
      { id: 'l2', title: 'Limit Laws and Shortcuts', duration: '18:05', youtubeId: 'dQw4w9WgXcQ', isPreview: false },
      { id: 'l3', title: 'Continuity Explained', duration: '15:30', youtubeId: 'dQw4w9WgXcQ', isPreview: false },
      { id: 'l4', title: 'Derivatives from First Principles', duration: '22:10', youtubeId: 'dQw4w9WgXcQ', isPreview: false },
      { id: 'l5', title: 'The Power, Product, and Chain Rules', duration: '24:00', youtubeId: 'dQw4w9WgXcQ', isPreview: false },
    ],
  },
  {
    id: 'c2',
    title: 'Mechanics: Forces, Motion & Energy',
    category: 'Physics',
    instructor: 'Vikram Joshi',
    price: 1799,
    rating: 4.6,
    reviewCount: 198,
    thumbnail: 'https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?w=600&h=400&fit=crop',
    description:
      'Newtonian mechanics from the ground up — covering kinematics, force diagrams, energy conservation, and rotational motion with JEE/NEET-style problem sets.',
    level: 'Intermediate',
    totalDuration: '10h 5m',
    lessons: [
      { id: 'l1', title: 'Kinematics in One Dimension', duration: '16:20', youtubeId: 'dQw4w9WgXcQ', isPreview: true },
      { id: 'l2', title: "Newton's Three Laws, Applied", duration: '20:15', youtubeId: 'dQw4w9WgXcQ', isPreview: false },
      { id: 'l3', title: 'Free Body Diagrams', duration: '19:40', youtubeId: 'dQw4w9WgXcQ', isPreview: false },
      { id: 'l4', title: 'Work, Energy, and Power', duration: '21:00', youtubeId: 'dQw4w9WgXcQ', isPreview: false },
    ],
  },
  {
    id: 'c3',
    title: 'Python for Beginners',
    category: 'Computer Science',
    instructor: 'Ananya Iyer',
    price: 999,
    rating: 4.9,
    reviewCount: 540,
    thumbnail: 'https://images.unsplash.com/photo-1526379879527-8559ecfcaec0?w=600&h=400&fit=crop',
    description:
      'Zero to confident: variables, loops, functions, and your first real projects. No prior coding experience needed.',
    level: 'Beginner',
    totalDuration: '12h 0m',
    lessons: [
      { id: 'l1', title: 'Setting Up Python', duration: '10:00', youtubeId: 'dQw4w9WgXcQ', isPreview: true },
      { id: 'l2', title: 'Variables and Data Types', duration: '14:30', youtubeId: 'dQw4w9WgXcQ', isPreview: true },
      { id: 'l3', title: 'Control Flow: if/else, loops', duration: '17:45', youtubeId: 'dQw4w9WgXcQ', isPreview: false },
      { id: 'l4', title: 'Functions and Scope', duration: '15:20', youtubeId: 'dQw4w9WgXcQ', isPreview: false },
      { id: 'l5', title: 'Lists, Dicts, and Tuples', duration: '19:10', youtubeId: 'dQw4w9WgXcQ', isPreview: false },
      { id: 'l6', title: 'Mini Project: To-Do App', duration: '25:00', youtubeId: 'dQw4w9WgXcQ', isPreview: false },
    ],
  },
  {
    id: 'c4',
    title: 'English Grammar Mastery',
    category: 'English',
    instructor: 'Fatima Khan',
    price: 799,
    rating: 4.5,
    reviewCount: 167,
    thumbnail: 'https://images.unsplash.com/photo-1455390582262-044cdead277a?w=600&h=400&fit=crop',
    description:
      'Master tenses, sentence structure, and common errors with practical exercises pulled from real writing.',
    level: 'Beginner',
    totalDuration: '6h 15m',
    lessons: [
      { id: 'l1', title: 'Parts of Speech, Refreshed', duration: '11:00', youtubeId: 'dQw4w9WgXcQ', isPreview: true },
      { id: 'l2', title: 'Tenses Without the Confusion', duration: '16:40', youtubeId: 'dQw4w9WgXcQ', isPreview: false },
    ],
  },
  {
    id: 'c5',
    title: 'Organic Chemistry Foundations',
    category: 'Chemistry',
    instructor: 'Dr. Sameer Verma',
    price: 1599,
    rating: 4.7,
    reviewCount: 221,
    thumbnail: 'https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?w=600&h=400&fit=crop',
    description:
      'Reaction mechanisms, nomenclature, and the logic behind organic chemistry — built for board exams and beyond.',
    level: 'Advanced',
    totalDuration: '9h 40m',
    lessons: [
      { id: 'l1', title: 'Naming Organic Compounds', duration: '18:00', youtubeId: 'dQw4w9WgXcQ', isPreview: true },
      { id: 'l2', title: 'Reaction Mechanisms 101', duration: '23:15', youtubeId: 'dQw4w9WgXcQ', isPreview: false },
    ],
  },
  {
    id: 'c6',
    title: 'JEE Main Crash Course',
    category: 'Test Prep',
    instructor: 'Multiple Instructors',
    price: 2999,
    rating: 4.8,
    reviewCount: 89,
    thumbnail: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=600&h=400&fit=crop',
    description:
      'A focused 60-day revision plan covering Physics, Chemistry, and Math high-weightage topics with timed mock tests.',
    level: 'Advanced',
    totalDuration: '40h 0m',
    lessons: [
      { id: 'l1', title: 'How to Use This Course', duration: '8:00', youtubeId: 'dQw4w9WgXcQ', isPreview: true },
      { id: 'l2', title: 'Physics Rapid Revision: Mechanics', duration: '30:00', youtubeId: 'dQw4w9WgXcQ', isPreview: false },
    ],
  },
]

// Per-user enrollment + progress data
export const mockEnrollments = [
  {
    userId: 'u1',
    courseId: 'c1',
    enrolledAt: '2026-04-12',
    progressPercent: 60,
    completedLessonIds: ['l1', 'l2', 'l3'],
  },
  {
    userId: 'u1',
    courseId: 'c3',
    enrolledAt: '2026-05-02',
    progressPercent: 33,
    completedLessonIds: ['l1', 'l2'],
  },
  {
    userId: 'u1',
    courseId: 'c4',
    enrolledAt: '2026-03-20',
    progressPercent: 100,
    completedLessonIds: ['l1', 'l2'],
  },
]

export const mockFeedback = [
  { id: 'f1', courseId: 'c1', userName: 'Rohan G.', rating: 5, comment: 'Finally understood limits properly. The pacing is great.', date: '2026-05-01' },
  { id: 'f2', courseId: 'c1', userName: 'Sneha P.', rating: 4, comment: 'Good course, wish there were more practice problems.', date: '2026-04-18' },
  { id: 'f3', courseId: 'c3', userName: 'Karthik R.', rating: 5, comment: 'Best beginner Python course I have tried.', date: '2026-05-10' },
]
