import { USE_MOCK_DATA, apiRequest, mockResolve } from './config'
import { mockFeedback } from './mockData'

// GET /courses/:id/feedback
export async function getFeedbackForCourse(courseId) {
  if (USE_MOCK_DATA) {
    return mockResolve(mockFeedback.filter((f) => f.courseId === courseId))
  }
  return apiRequest(`/courses/${courseId}/feedback`)
}

// POST /courses/:id/feedback  { rating, comment }
export async function submitFeedback({ courseId, userName, rating, comment }) {
  if (USE_MOCK_DATA) {
    const entry = {
      id: `f${Date.now()}`,
      courseId,
      userName,
      rating,
      comment,
      date: new Date().toISOString().slice(0, 10),
    }
    mockFeedback.unshift(entry)
    return mockResolve(entry)
  }
  return apiRequest(`/courses/${courseId}/feedback`, { method: 'POST', body: { rating, comment } })
}

// POST /support/tickets  { subject, message }
export async function submitSupportTicket({ name, email, subject, message }) {
  if (USE_MOCK_DATA) {
    return mockResolve({ id: `t${Date.now()}`, status: 'open' })
  }
  return apiRequest('/support/tickets', { method: 'POST', body: { name, email, subject, message } })
}
