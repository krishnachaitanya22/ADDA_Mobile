import { USE_MOCK_DATA, apiRequest, mockResolve } from './config'
import { mockCourses, mockCategories } from './mockData'

// GET /courses?search=&category=
export async function getCourses({ search = '', category = '' } = {}) {
  if (USE_MOCK_DATA) {
    let results = [...mockCourses]
    if (category) results = results.filter((c) => c.category === category)
    if (search) {
      const q = search.toLowerCase()
      results = results.filter(
        (c) => c.title.toLowerCase().includes(q) || c.instructor.toLowerCase().includes(q)
      )
    }
    return mockResolve(results)
  }

  const params = new URLSearchParams({ search, category }).toString()
  return apiRequest(`/courses?${params}`)
}

// GET /courses/:id
export async function getCourseById(id) {
  if (USE_MOCK_DATA) {
    const course = mockCourses.find((c) => c.id === id)
    return mockResolve(course || null)
  }
  return apiRequest(`/courses/${id}`)
}

// GET /categories
export async function getCategories() {
  if (USE_MOCK_DATA) {
    return mockResolve(mockCategories)
  }
  return apiRequest('/categories')
}

// ---- Admin-only course management ----

// POST /admin/courses
export async function createCourse(courseData) {
  if (USE_MOCK_DATA) {
    const newCourse = { id: `c${Date.now()}`, rating: 0, reviewCount: 0, lessons: [], ...courseData }
    mockCourses.push(newCourse)
    return mockResolve(newCourse)
  }
  return apiRequest('/admin/courses', { method: 'POST', body: courseData })
}

// PUT /admin/courses/:id
export async function updateCourse(id, updates) {
  if (USE_MOCK_DATA) {
    const idx = mockCourses.findIndex((c) => c.id === id)
    if (idx === -1) return mockResolve(null)
    mockCourses[idx] = { ...mockCourses[idx], ...updates }
    return mockResolve(mockCourses[idx])
  }
  return apiRequest(`/admin/courses/${id}`, { method: 'PUT', body: updates })
}

// DELETE /admin/courses/:id
export async function deleteCourse(id) {
  if (USE_MOCK_DATA) {
    const idx = mockCourses.findIndex((c) => c.id === id)
    if (idx !== -1) mockCourses.splice(idx, 1)
    return mockResolve({ success: true })
  }
  return apiRequest(`/admin/courses/${id}`, { method: 'DELETE' })
}
