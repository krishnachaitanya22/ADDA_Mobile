import { USE_MOCK_DATA, apiRequest, mockResolve } from './config';
import { mockEnrollments } from './mockData';

// ============================================================================
// RAZORPAY INTEGRATION NOTES — MOBILE (React Native)
// ============================================================================
// Mobile uses a different SDK than the web app: `react-native-razorpay`
// instead of the Razorpay Checkout <script>. The backend endpoints
// (create-order, verify) are IDENTICAL to the web app — same Razorpay
// account, same order/signature verification logic server-side. Only the
// client-side trigger differs.
//
// Setup once ready:
//   npm install react-native-razorpay
//   import RazorpayCheckout from 'react-native-razorpay'
//
// 1. Backend: POST /payments/create-order { courseId } -> { orderId, amount, keyId }
// 2. Mobile: RazorpayCheckout.open({ key: keyId, order_id: orderId, ... })
//    opens Razorpay's native payment sheet (UPI apps, cards, etc.)
// 3. Mobile: on success, POST /payments/verify { orderId, paymentId, signature }
// 4. Backend verifies signature server-side and creates the enrollment —
//    same verify endpoint and same logic as the web app.
// ============================================================================

export async function createPaymentOrder(courseId) {
  if (USE_MOCK_DATA) {
    return mockResolve({ orderId: `order_mock_${courseId}_${Date.now()}`, amount: 0, keyId: 'mock_key' });
  }
  return apiRequest('/payments/create-order', { method: 'POST', body: { courseId } });
}

export async function verifyAndEnroll({ userId, courseId, orderId, paymentId, signature }) {
  if (USE_MOCK_DATA) {
    const already = mockEnrollments.some((e) => e.userId === userId && e.courseId === courseId);
    if (!already) {
      mockEnrollments.push({
        userId,
        courseId,
        enrolledAt: new Date().toISOString().slice(0, 10),
        progressPercent: 0,
        completedLessonIds: [],
      });
    }
    return mockResolve({ success: true });
  }
  return apiRequest('/payments/verify', {
    method: 'POST',
    body: { courseId, orderId, paymentId, signature },
  });
}

// Mobile checkout flow. In mock mode, simulates success after a short
// delay instead of opening the real Razorpay native sheet.
//
// Real implementation (once react-native-razorpay is installed):
//
//   import RazorpayCheckout from 'react-native-razorpay';
//
//   const order = await createPaymentOrder(course.id);
//   RazorpayCheckout.open({
//     key: order.keyId,
//     amount: order.amount,
//     currency: 'INR',
//     name: 'Preparation Adda',
//     description: course.title,
//     order_id: order.orderId,
//     prefill: { name: user.name, email: user.email },
//     theme: { color: '#1E1B4B' },
//   }).then(async (data) => {
//     await verifyAndEnroll({
//       userId: user.id,
//       courseId: course.id,
//       orderId: data.razorpay_order_id,
//       paymentId: data.razorpay_payment_id,
//       signature: data.razorpay_signature,
//     });
//     onSuccess();
//   }).catch((error) => onFailure(error));
//
export async function openCheckout({ course, user, onSuccess, onFailure }) {
  if (USE_MOCK_DATA) {
    setTimeout(async () => {
      await verifyAndEnroll({ userId: user.id, courseId: course.id, orderId: 'mock', paymentId: 'mock', signature: 'mock' });
      onSuccess();
    }, 900);
    return;
  }

  try {
    // Real implementation goes here once react-native-razorpay is added.
    // Left as a clear extension point — see comment block above.
    onFailure(new Error('Real payment flow not yet wired. Install react-native-razorpay first.'));
  } catch (err) {
    onFailure(err);
  }
}
