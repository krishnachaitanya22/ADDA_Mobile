// ============================================================================
// API CONFIGURATION — mobile version.
//
// This mirrors src/api/config.js from the web app exactly in spirit. The
// ONLY difference from the web version: localStorage doesn't exist on
// mobile, so token storage uses AsyncStorage instead. Every function
// signature and every other file in src/api/ is identical to the web app,
// so business logic ports over with no rewriting.
//
// Same rule as web: set USE_MOCK_DATA = false and set BASE_URL once your
// backend is live. No screen needs to change.
// ============================================================================
import AsyncStorage from '@react-native-async-storage/async-storage';

export const USE_MOCK_DATA = true;

export const BASE_URL = 'http://localhost:4000/api'; // replace with your deployed backend URL

export const MOCK_DELAY_MS = 500;

let cachedToken = null;

export async function getAuthToken() {
  if (cachedToken !== null) return cachedToken;
  cachedToken = await AsyncStorage.getItem('auth_token');
  return cachedToken;
}

export async function setAuthToken(token) {
  cachedToken = token;
  if (token) await AsyncStorage.setItem('auth_token', token);
  else await AsyncStorage.removeItem('auth_token');
}

export async function apiRequest(path, { method = 'GET', body, headers = {} } = {}) {
  const token = await getAuthToken();

  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...headers,
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  const data = await res.json().catch(() => null);

  if (!res.ok) {
    const message = data?.message || `Request failed (${res.status})`;
    throw new ApiError(message, res.status, data);
  }

  return data;
}

export class ApiError extends Error {
  constructor(message, status, data) {
    super(message);
    this.status = status;
    this.data = data;
  }
}

export function mockResolve(value, delay = MOCK_DELAY_MS) {
  return new Promise((resolve) => setTimeout(() => resolve(value), delay));
}
