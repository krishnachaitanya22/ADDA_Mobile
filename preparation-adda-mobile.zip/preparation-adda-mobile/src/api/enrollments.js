import { USE_MOCK_DATA, apiRequest, mockResolve } from './config'
import { mockEnrollments, mockCourses } from './mockData'

// GET /students/me/enrollments -> [{ course, progressPercent, completedLessonIds }]
export async function getMyEnrollments(userId) {
  if (USE_MOCK_DATA) {
    const enrollments = mockEnrollments
      .filter((e) => e.userId === userId)
      .map((e) => ({
        ...e,
        course: mockCourses.find((c) => c.id === e.courseId),
      }))
    return mockResolve(enrollments)
  }
  return apiRequest('/students/me/enrollments')
}

// GET /students/me/enrollments/:courseId  -> single enrollment or null
export async function getEnrollmentForCourse(userId, courseId) {
  if (USE_MOCK_DATA) {
    const enrollment = mockEnrollments.find((e) => e.userId === userId && e.courseId === courseId)
    return mockResolve(enrollment || null)
  }
  return apiRequest(`/students/me/enrollments/${courseId}`)
}

// POST /students/me/progress  { courseId, lessonId }
// Marks a lesson complete and recalculates progressPercent.
export async function markLessonComplete({ userId, courseId, lessonId }) {
  if (USE_MOCK_DATA) {
    const enrollment = mockEnrollments.find((e) => e.userId === userId && e.courseId === courseId)
    const course = mockCourses.find((c) => c.id === courseId)
    if (!enrollment || !course) return mockResolve(null)

    if (!enrollment.completedLessonIds.includes(lessonId)) {
      enrollment.completedLessonIds.push(lessonId)
    }
    enrollment.progressPercent = Math.round(
      (enrollment.completedLessonIds.length / course.lessons.length) * 100
    )
    return mockResolve(enrollment)
  }
  return apiRequest('/students/me/progress', { method: 'POST', body: { courseId, lessonId } })
}
