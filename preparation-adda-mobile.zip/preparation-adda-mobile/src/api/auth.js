import { USE_MOCK_DATA, apiRequest, mockResolve, setAuthToken, getAuthToken, ApiError } from './config';
import { mockUsers } from './mockData';

export async function loginUser({ email, password }) {
  if (USE_MOCK_DATA) {
    const user = mockUsers.find((u) => u.email === email && u.password === password);
    if (!user) {
      throw new ApiError('Invalid email or password', 401);
    }
    const { password: _pw, ...safeUser } = user;
    const fakeToken = `mock-token-${user.id}`;
    await setAuthToken(fakeToken);
    return mockResolve({ token: fakeToken, user: safeUser });
  }

  const data = await apiRequest('/auth/login', { method: 'POST', body: { email, password } });
  await setAuthToken(data.token);
  return data;
}

export async function signupUser({ name, email, password }) {
  if (USE_MOCK_DATA) {
    const exists = mockUsers.some((u) => u.email === email);
    if (exists) {
      throw new ApiError('An account with this email already exists', 409);
    }
    const newUser = { id: `u${Date.now()}`, name, email, role: 'student' };
    mockUsers.push({ ...newUser, password });
    const fakeToken = `mock-token-${newUser.id}`;
    await setAuthToken(fakeToken);
    return mockResolve({ token: fakeToken, user: newUser });
  }

  const data = await apiRequest('/auth/signup', { method: 'POST', body: { name, email, password } });
  await setAuthToken(data.token);
  return data;
}

export async function getCurrentUser() {
  if (USE_MOCK_DATA) {
    const token = await getAuthToken();
    if (!token) return mockResolve(null);
    const id = token.replace('mock-token-', '');
    const user = mockUsers.find((u) => u.id === id);
    if (!user) return mockResolve(null);
    const { password: _pw, ...safeUser } = user;
    return mockResolve(safeUser);
  }

  try {
    const data = await apiRequest('/auth/me');
    return data.user;
  } catch {
    return null;
  }
}

export async function logoutUser() {
  await setAuthToken(null);
}
