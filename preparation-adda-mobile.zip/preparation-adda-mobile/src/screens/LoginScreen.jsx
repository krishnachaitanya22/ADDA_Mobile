import { useState } from 'react';
import { View, Text, TextInput, Pressable, SafeAreaView, KeyboardAvoidingView, Platform } from 'react-native';
import { useAuth } from '../context/AuthContext';

export default function LoginScreen({ navigation }) {
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  async function handleSubmit() {
    setError('');
    setIsSubmitting(true);
    try {
      const user = await login(email, password);
      navigation.replace(user.role === 'admin' ? 'AdminTabs' : 'MainTabs');
    } catch (err) {
      setError(err.message || 'Something went wrong. Try again.');
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <SafeAreaView className="flex-1 bg-paper">
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} className="flex-1 justify-center px-6">
        <Text className="font-bold text-2xl text-ink mb-1">Welcome back</Text>
        <Text className="text-slate mb-8">Log in to continue your courses.</Text>

        <Field label="Email" value={email} onChange={setEmail} placeholder="you@example.com" keyboardType="email-address" />
        <Field label="Password" value={password} onChange={setPassword} placeholder="••••••••" secureTextEntry />

        {error ? <Text className="text-coral text-sm mb-2">{error}</Text> : null}

        <Pressable
          onPress={handleSubmit}
          disabled={isSubmitting}
          className="bg-ink rounded-xl py-4 mt-2 items-center"
          style={{ opacity: isSubmitting ? 0.6 : 1 }}
        >
          <Text className="text-paper font-semibold">{isSubmitting ? 'Logging in…' : 'Log in'}</Text>
        </Pressable>

        <Pressable onPress={() => navigation.navigate('Signup')} className="mt-6">
          <Text className="text-slate text-center text-sm">
            New here? <Text className="text-ink font-medium">Create an account</Text>
          </Text>
        </Pressable>

        <View className="mt-8 p-4 rounded-xl bg-amber/10 border border-amber/20">
          <Text className="text-xs text-ink/70 leading-relaxed">
            <Text className="font-medium">Demo accounts —</Text> Student: aditi@example.com / password123. Admin: admin@preparationadda.com / admin123.
          </Text>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

function Field({ label, value, onChange, placeholder, secureTextEntry, keyboardType }) {
  return (
    <View className="mb-4">
      <Text className="text-sm font-medium text-ink mb-1.5">{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChange}
        placeholder={placeholder}
        secureTextEntry={secureTextEntry}
        keyboardType={keyboardType}
        autoCapitalize="none"
        className="border border-ink/15 rounded-xl px-4 py-3 bg-white text-ink"
      />
    </View>
  );
}
