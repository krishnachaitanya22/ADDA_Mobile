import { useState, useMemo } from 'react';
import { View, Text, TextInput, ScrollView, Pressable, SafeAreaView } from 'react-native';
import CourseCard from '../components/CourseCard';
import { mockCourses, mockCategories } from '../api/mockData';

export default function CatalogScreen({ navigation }) {
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState('');

  const filtered = useMemo(() => {
    return mockCourses.filter((c) => {
      const matchesCategory = !activeCategory || c.category === activeCategory;
      const q = search.toLowerCase();
      const matchesSearch = !search || c.title.toLowerCase().includes(q) || c.instructor.toLowerCase().includes(q);
      return matchesCategory && matchesSearch;
    });
  }, [search, activeCategory]);

  return (
    <SafeAreaView className="flex-1 bg-paper">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Hero */}
        <View className="bg-ink px-6 pt-6 pb-8">
          <Text className="text-amber font-semibold text-xs uppercase tracking-wide mb-2">For students, by educators</Text>
          <Text className="text-paper font-bold text-3xl leading-tight mb-3">
            Learn at your pace.{'\n'}Track every step.
          </Text>
          <TextInput
            value={search}
            onChangeText={setSearch}
            placeholder="Search courses or instructors…"
            placeholderTextColor="rgba(250,250,247,0.5)"
            className="bg-white/10 border border-white/20 text-white rounded-xl px-4 py-3 mt-2"
          />
        </View>

        {/* Category filters */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} className="px-6 pt-4 pb-2" contentContainerStyle={{ gap: 8 }}>
          <FilterChip label="All" active={activeCategory === ''} onPress={() => setActiveCategory('')} />
          {mockCategories.map((cat) => (
            <FilterChip key={cat} label={cat} active={activeCategory === cat} onPress={() => setActiveCategory(cat)} />
          ))}
        </ScrollView>

        {/* Course list */}
        <View className="px-6 pt-4 pb-8">
          {filtered.length === 0 ? (
            <View className="items-center py-16">
              <Text className="font-semibold text-lg text-ink mb-1">No courses match that search.</Text>
              <Text className="text-slate text-center">Try a different keyword or browse all categories.</Text>
            </View>
          ) : (
            filtered.map((course) => (
              <CourseCard
                key={course.id}
                course={course}
                onPress={() => navigation.navigate('CourseDetail', { courseId: course.id })}
              />
            ))
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function FilterChip({ label, active, onPress }) {
  return (
    <Pressable
      onPress={onPress}
      className={`px-4 py-2 rounded-full border ${active ? 'bg-ink border-ink' : 'bg-white border-ink/10'}`}
    >
      <Text className={`text-sm font-medium ${active ? 'text-paper' : 'text-slate'}`}>{label}</Text>
    </Pressable>
  );
}
