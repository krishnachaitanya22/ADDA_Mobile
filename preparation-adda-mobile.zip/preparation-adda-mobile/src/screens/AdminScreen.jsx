import { useState } from 'react';
import { View, Text, ScrollView, Pressable, Image, TextInput, SafeAreaView, Alert } from 'react-native';
import { mockCourses, mockCategories } from '../api/mockData';

const emptyForm = {
  title: '', category: 'Mathematics', instructor: '', price: '', level: 'Beginner',
  totalDuration: '', thumbnail: 'https://images.unsplash.com/photo-1501504905252-473c47e087f8?w=600&h=400&fit=crop', description: '',
};

export default function AdminScreen() {
  const [, forceRerender] = useState(0);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(emptyForm);

  function startEdit(course) {
    setEditingId(course.id);
    setForm({ title: course.title, category: course.category, instructor: course.instructor, price: String(course.price), level: course.level, totalDuration: course.totalDuration, thumbnail: course.thumbnail, description: course.description });
  }
  function startNew() { setEditingId('new'); setForm(emptyForm); }
  function cancelEdit() { setEditingId(null); setForm(emptyForm); }

  function handleSave() {
    const payload = { ...form, price: Number(form.price) };
    if (editingId === 'new') {
      mockCourses.push({ id: 'c' + Date.now(), rating: 0, reviewCount: 0, lessons: [], ...payload });
    } else {
      const idx = mockCourses.findIndex((c) => c.id === editingId);
      mockCourses[idx] = { ...mockCourses[idx], ...payload };
    }
    cancelEdit();
    forceRerender((n) => n + 1);
  }

  function handleDelete(id) {
    Alert.alert('Delete this course?', 'This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => {
        const idx = mockCourses.findIndex((c) => c.id === id);
        if (idx !== -1) mockCourses.splice(idx, 1);
        forceRerender((n) => n + 1);
      }},
    ]);
  }

  const totalRevenuePotential = mockCourses.reduce((sum, c) => sum + c.price * c.reviewCount, 0);

  return (
    <SafeAreaView className="flex-1 bg-paper">
      <ScrollView showsVerticalScrollIndicator={false} className="px-6 pt-6">
        <View className="flex-row items-center justify-between mb-4">
          <View>
            <Text className="font-bold text-2xl text-ink">Manage courses</Text>
            <Text className="text-slate mt-1">{mockCourses.length} courses published</Text>
          </View>
        </View>

        <Pressable onPress={startNew} className="bg-amber rounded-xl py-3 items-center mb-4">
          <Text className="text-ink font-semibold">+ New course</Text>
        </Pressable>

        <View className="flex-row gap-3 mb-6">
          <StatCard label="Courses" value={String(mockCourses.length)} />
          <StatCard label="Avg rating" value={mockCourses.length ? (mockCourses.reduce((s, c) => s + c.rating, 0) / mockCourses.length).toFixed(1) : '—'} />
          <StatCard label="Est. revenue" value={`₹${(totalRevenuePotential / 1000).toFixed(0)}k`} />
        </View>

        {editingId && (
          <View className="bg-white rounded-2xl border border-ink/10 p-4 mb-6">
            <Text className="font-semibold text-ink mb-3">{editingId === 'new' ? 'New course' : 'Edit course'}</Text>
            <Field label="Title" value={form.title} onChange={(v) => setForm({ ...form, title: v })} />
            <Field label="Instructor" value={form.instructor} onChange={(v) => setForm({ ...form, instructor: v })} />
            <Field label="Price (₹)" value={form.price} onChange={(v) => setForm({ ...form, price: v })} keyboardType="numeric" />
            <Field label="Total duration" value={form.totalDuration} onChange={(v) => setForm({ ...form, totalDuration: v })} placeholder="e.g. 8h 20m" />
            <Field label="Description" value={form.description} onChange={(v) => setForm({ ...form, description: v })} multiline />

            <View className="flex-row gap-3 mt-2">
              <Pressable onPress={handleSave} className="bg-ink rounded-xl px-5 py-2.5"><Text className="text-paper font-medium">Save</Text></Pressable>
              <Pressable onPress={cancelEdit} className="border border-ink/15 rounded-xl px-5 py-2.5"><Text className="text-ink font-medium">Cancel</Text></Pressable>
            </View>
          </View>
        )}

        {mockCourses.map((c) => (
          <View key={c.id} className="flex-row items-center gap-3 bg-white rounded-2xl border border-ink/10 p-3 mb-3">
            <Image source={{ uri: c.thumbnail }} className="w-12 h-12 rounded-lg" resizeMode="cover" />
            <View className="flex-1">
              <Text className="font-medium text-ink text-sm" numberOfLines={1}>{c.title}</Text>
              <Text className="text-xs text-slate-light">{c.instructor} · ₹{c.price.toLocaleString('en-IN')}</Text>
            </View>
            <Pressable onPress={() => startEdit(c)} className="px-2"><Text className="text-ink font-medium text-sm">Edit</Text></Pressable>
            <Pressable onPress={() => handleDelete(c.id)} className="px-2"><Text className="text-coral font-medium text-sm">Delete</Text></Pressable>
          </View>
        ))}
        <View className="h-10" />
      </ScrollView>
    </SafeAreaView>
  );
}

function StatCard({ label, value }) {
  return (
    <View className="flex-1 bg-white rounded-xl border border-ink/10 p-3">
      <Text className="text-xs text-slate-light uppercase">{label}</Text>
      <Text className="font-bold text-xl text-ink mt-1">{value}</Text>
    </View>
  );
}

function Field({ label, value, onChange, placeholder, keyboardType, multiline }) {
  return (
    <View className="mb-3">
      <Text className="text-sm font-medium text-ink mb-1">{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChange}
        placeholder={placeholder}
        keyboardType={keyboardType}
        multiline={multiline}
        className="border border-ink/15 rounded-lg px-3 py-2 bg-white text-ink"
        style={multiline ? { minHeight: 70, textAlignVertical: 'top' } : {}}
      />
    </View>
  );
}
