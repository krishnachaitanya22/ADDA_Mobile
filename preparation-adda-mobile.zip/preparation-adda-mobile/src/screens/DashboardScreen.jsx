import { View, Text, ScrollView, Pressable, Image, SafeAreaView } from 'react-native';
import { useAuth } from '../context/AuthContext';
import { mockEnrollments, mockCourses } from '../api/mockData';
import ProgressRing from '../components/ProgressRing';

export default function DashboardScreen({ navigation }) {
  const { user } = useAuth();
  const enrollments = mockEnrollments
    .filter((e) => e.userId === user.id)
    .map((e) => ({ ...e, course: mockCourses.find((c) => c.id === e.courseId) }));

  const inProgress = enrollments.filter((e) => e.progressPercent < 100);
  const completed = enrollments.filter((e) => e.progressPercent >= 100);

  return (
    <SafeAreaView className="flex-1 bg-paper">
      <ScrollView showsVerticalScrollIndicator={false} className="px-6 pt-6">
        <Text className="font-bold text-2xl text-ink">Hey {user.name.split(' ')[0]} 👋</Text>
        <Text className="text-slate mt-1 mb-6">Here's where you left off.</Text>

        {enrollments.length === 0 ? (
          <View className="items-center py-16 bg-white rounded-2xl border border-ink/10">
            <Text className="font-semibold text-lg text-ink mb-1">No courses yet.</Text>
            <Text className="text-slate mb-4">Find something worth learning.</Text>
            <Pressable onPress={() => navigation.navigate('Catalog')} className="bg-ink rounded-xl px-5 py-2.5">
              <Text className="text-paper font-medium">Browse courses</Text>
            </Pressable>
          </View>
        ) : (
          <>
            {inProgress.length > 0 && (
              <View className="mb-6">
                <Text className="font-semibold text-lg text-ink mb-3">Continue learning</Text>
                {inProgress.map((e) => (
                  <EnrollmentRow key={e.courseId} enrollment={e} onPress={() => navigation.navigate('CourseDetail', { courseId: e.course.id })} />
                ))}
              </View>
            )}
            {completed.length > 0 && (
              <View className="mb-6">
                <Text className="font-semibold text-lg text-ink mb-3">Completed</Text>
                {completed.map((e) => (
                  <EnrollmentRow key={e.courseId} enrollment={e} onPress={() => navigation.navigate('CourseDetail', { courseId: e.course.id })} />
                ))}
              </View>
            )}
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

function EnrollmentRow({ enrollment, onPress }) {
  const { course, progressPercent } = enrollment;
  return (
    <Pressable onPress={onPress} className="flex-row gap-3 p-4 bg-white rounded-2xl border border-ink/10 mb-3">
      <Image source={{ uri: course.thumbnail }} className="w-16 h-16 rounded-xl" resizeMode="cover" />
      <View className="flex-1">
        <Text className="font-medium text-ink text-sm" numberOfLines={2}>{course.title}</Text>
        <Text className="text-xs text-slate mt-0.5">{course.instructor}</Text>
        <View className="flex-row items-center gap-2 mt-2">
          <ProgressRing percent={progressPercent} size={26} strokeWidth={3} />
          <Text className="text-xs text-slate">{progressPercent}% complete</Text>
        </View>
      </View>
    </Pressable>
  );
}
