import { useState } from 'react';
import { View, Text, ScrollView, Pressable, SafeAreaView, Image, TextInput } from 'react-native';
import { WebView } from 'react-native-webview';
import Svg, { Path, Rect, Circle } from 'react-native-svg';
import { useAuth } from '../context/AuthContext';
import { mockCourses, mockEnrollments, mockFeedback } from '../api/mockData';
import { openCheckout } from '../api/payments';
import ProgressRing from '../components/ProgressRing';
import { StarIcon } from '../components/CourseCard';

export default function CourseDetailScreen({ route, navigation }) {
  const { courseId } = route.params;
  const { user } = useAuth();
  const course = mockCourses.find((c) => c.id === courseId);
  const [, forceRerender] = useState(0);
  const [activeLessonId, setActiveLessonId] = useState(course ? course.lessons[0].id : null);
  const [isPaying, setIsPaying] = useState(false);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [submitted, setSubmitted] = useState(false);

  if (!course) {
    return (
      <SafeAreaView className="flex-1 bg-paper items-center justify-center px-6">
        <Text className="font-semibold text-lg text-ink mb-2">This course doesn't exist, or was removed.</Text>
        <Pressable onPress={() => navigation.goBack()}><Text className="text-ink underline">Back to catalog</Text></Pressable>
      </SafeAreaView>
    );
  }

  const enrollment = user ? mockEnrollments.find((e) => e.userId === user.id && e.courseId === course.id) : null;
  const isEnrolled = Boolean(enrollment);
  const activeLesson = course.lessons.find((l) => l.id === activeLessonId);
  const canWatch = (lesson) => isEnrolled || lesson.isPreview;
  const feedback = mockFeedback.filter((f) => f.courseId === course.id);

  function handleBuy() {
    if (!user) { navigation.navigate('Login'); return; }
    setIsPaying(true);
    openCheckout({
      course,
      user,
      onSuccess: () => { setIsPaying(false); forceRerender((n) => n + 1); },
      onFailure: () => setIsPaying(false),
    });
  }

  function handleMarkComplete(lessonId) {
    if (!enrollment) return;
    if (!enrollment.completedLessonIds.includes(lessonId)) enrollment.completedLessonIds.push(lessonId);
    enrollment.progressPercent = Math.round((enrollment.completedLessonIds.length / course.lessons.length) * 100);
    forceRerender((n) => n + 1);
  }

  function handleSubmitFeedback() {
    mockFeedback.unshift({ id: 'f' + Date.now(), courseId: course.id, userName: user.name, rating, comment });
    setComment('');
    setSubmitted(true);
    forceRerender((n) => n + 1);
  }

  return (
    <SafeAreaView className="flex-1 bg-paper">
      <ScrollView showsVerticalScrollIndicator={false}>
        <View className="px-6 pt-4">
          <Text className="text-xs font-semibold text-amber-dark uppercase tracking-wide">{course.category}</Text>
          <Text className="font-bold text-2xl text-ink mt-1">{course.title}</Text>
          <Text className="text-slate mt-1">{course.instructor} · {course.level} · {course.totalDuration}</Text>
        </View>

        {/* Video player or lock screen */}
        <View className="mt-4 mx-6 rounded-2xl overflow-hidden" style={{ aspectRatio: 16 / 9 }}>
          {canWatch(activeLesson) ? (
            <WebView
              source={{ uri: `https://www.youtube.com/embed/${activeLesson.youtubeId}` }}
              allowsFullscreenVideo
              style={{ flex: 1, backgroundColor: '#000' }}
            />
          ) : (
            <View className="flex-1 bg-ink items-center justify-center">
              <LockIcon color="#FAFAF7" />
              <Text className="text-paper font-medium mt-2">Buy this course to unlock this lesson</Text>
            </View>
          )}
        </View>

        {canWatch(activeLesson) && isEnrolled && (
          <Pressable
            onPress={() => handleMarkComplete(activeLesson.id)}
            disabled={enrollment.completedLessonIds.includes(activeLesson.id)}
            className="mx-6 mt-4 self-start px-4 py-2 rounded-xl border border-success/30 bg-success/5"
          >
            <Text className="text-success text-sm font-medium">
              {enrollment.completedLessonIds.includes(activeLesson.id) ? '✓ Marked complete' : 'Mark this lesson complete'}
            </Text>
          </Pressable>
        )}

        {/* Purchase / progress card */}
        <View className="mx-6 mt-6 bg-white rounded-2xl border border-ink/10 p-5">
          {isEnrolled ? (
            <View className="flex-row items-center gap-3">
              <ProgressRing percent={enrollment.progressPercent} />
              <View>
                <Text className="font-medium text-ink text-sm">You're enrolled</Text>
                <Text className="text-xs text-slate">{enrollment.progressPercent}% complete</Text>
              </View>
            </View>
          ) : (
            <>
              <Text className="font-bold text-2xl text-ink mb-3">₹{course.price.toLocaleString('en-IN')}</Text>
              <Pressable onPress={handleBuy} disabled={isPaying} className="bg-amber rounded-xl py-4 items-center" style={{ opacity: isPaying ? 0.6 : 1 }}>
                <Text className="text-ink font-semibold">{isPaying ? 'Opening checkout…' : 'Buy this course'}</Text>
              </Pressable>
              <Text className="text-xs text-slate-light text-center mt-2">Secure payment via Razorpay</Text>
            </>
          )}

          <View className="h-px bg-ink/10 my-4" />
          <Text className="text-sm font-medium text-ink mb-2">{course.lessons.length} lessons</Text>
          {course.lessons.map((lesson) => {
            const locked = !canWatch(lesson);
            const done = enrollment && enrollment.completedLessonIds.includes(lesson.id);
            return (
              <Pressable
                key={lesson.id}
                onPress={() => !locked && setActiveLessonId(lesson.id)}
                disabled={locked}
                className={`flex-row items-center gap-2 px-2 py-2.5 rounded-lg ${activeLessonId === lesson.id ? 'bg-ink/5' : ''}`}
                style={{ opacity: locked ? 0.5 : 1 }}
              >
                {locked ? <LockIcon size={14} color="#1E1B4B" /> : done ? <CheckCircle /> : <View className="w-3.5 h-3.5 rounded-full border-2 border-ink/20" />}
                <Text className="flex-1 text-ink text-sm">{lesson.title}</Text>
                <Text className="text-xs text-slate-light">{lesson.duration}</Text>
              </Pressable>
            );
          })}
        </View>

        {/* Description */}
        <View className="mx-6 mt-6">
          <Text className="font-semibold text-lg text-ink mb-2">About this course</Text>
          <Text className="text-slate leading-relaxed">{course.description}</Text>
        </View>

        {/* Reviews */}
        <View className="mx-6 mt-6 mb-10">
          <Text className="font-semibold text-lg text-ink mb-3">Reviews</Text>

          {isEnrolled && (
            <View className="bg-white rounded-2xl border border-ink/10 p-4 mb-4">
              <View className="flex-row gap-1 mb-2">
                {[1, 2, 3, 4, 5].map((n) => (
                  <Pressable key={n} onPress={() => setRating(n)}>
                    <StarIcon filled={n <= rating} size={20} />
                  </Pressable>
                ))}
              </View>
              <TextInput
                value={comment}
                onChangeText={setComment}
                placeholder="How was this course?"
                multiline
                className="border border-ink/15 rounded-lg px-3 py-2 text-sm mb-3"
                style={{ minHeight: 60 }}
              />
              <Pressable onPress={handleSubmitFeedback} className="self-start bg-ink rounded-xl px-4 py-2">
                <Text className="text-paper text-sm font-medium">Post review</Text>
              </Pressable>
              {submitted && <Text className="text-success text-xs mt-2">Thanks for your feedback!</Text>}
            </View>
          )}

          {feedback.length === 0 ? (
            <Text className="text-slate text-sm">No reviews yet. Be the first to leave one.</Text>
          ) : (
            feedback.map((f) => (
              <View key={f.id} className="border-b border-ink/10 pb-3 mb-3">
                <View className="flex-row items-center gap-2 mb-1">
                  <Text className="font-medium text-ink text-sm">{f.userName}</Text>
                  <View className="flex-row">
                    {Array.from({ length: 5 }).map((_, i) => <StarIcon key={i} filled={i < f.rating} size={11} />)}
                  </View>
                </View>
                <Text className="text-sm text-slate">{f.comment}</Text>
              </View>
            ))
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function LockIcon({ size = 24, color = '#1E1B4B' }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color}>
      <Rect x="5" y="11" width="14" height="9" rx="2" strokeWidth={2} />
      <Path d="M8 11V7a4 4 0 118 0v4" strokeWidth={2} />
    </Svg>
  );
}

function CheckCircle() {
  return (
    <Svg width={14} height={14} viewBox="0 0 24 24" fill="none">
      <Circle cx="12" cy="12" r="10" fill="#16A34A" />
      <Path d="M7 12.5l3 3 6-6" stroke="white" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />
    </Svg>
  );
}
