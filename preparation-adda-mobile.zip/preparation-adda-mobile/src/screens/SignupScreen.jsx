import { useState } from 'react';
import { View, Text, TextInput, Pressable, SafeAreaView, KeyboardAvoidingView, Platform } from 'react-native';
import { useAuth } from '../context/AuthContext';

export default function SignupScreen({ navigation }) {
  const { signup } = useAuth();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  async function handleSubmit() {
    setError('');
    setIsSubmitting(true);
    try {
      await signup(name, email, password);
      navigation.replace('MainTabs');
    } catch (err) {
      setError(err.message || 'Something went wrong. Try again.');
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <SafeAreaView className="flex-1 bg-paper">
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} className="flex-1 justify-center px-6">
        <Text className="font-bold text-2xl text-ink mb-1">Create your account</Text>
        <Text className="text-slate mb-8">Start learning in under a minute.</Text>

        <Field label="Full name" value={name} onChange={setName} placeholder="Aditi Sharma" />
        <Field label="Email" value={email} onChange={setEmail} placeholder="you@example.com" keyboardType="email-address" />
        <Field label="Password" value={password} onChange={setPassword} placeholder="At least 8 characters" secureTextEntry />

        {error ? <Text className="text-coral text-sm mb-2">{error}</Text> : null}

        <Pressable
          onPress={handleSubmit}
          disabled={isSubmitting}
          className="bg-ink rounded-xl py-4 mt-2 items-center"
          style={{ opacity: isSubmitting ? 0.6 : 1 }}
        >
          <Text className="text-paper font-semibold">{isSubmitting ? 'Creating account…' : 'Create account'}</Text>
        </Pressable>

        <Pressable onPress={() => navigation.navigate('Login')} className="mt-6">
          <Text className="text-slate text-center text-sm">
            Already have an account? <Text className="text-ink font-medium">Log in</Text>
          </Text>
        </Pressable>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

function Field({ label, value, onChange, placeholder, secureTextEntry, keyboardType }) {
  return (
    <View className="mb-4">
      <Text className="text-sm font-medium text-ink mb-1.5">{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChange}
        placeholder={placeholder}
        secureTextEntry={secureTextEntry}
        keyboardType={keyboardType}
        autoCapitalize="none"
        className="border border-ink/15 rounded-xl px-4 py-3 bg-white text-ink"
      />
    </View>
  );
}
