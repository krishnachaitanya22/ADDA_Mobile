import { useState } from 'react';
import { View, Text, TextInput, Pressable, SafeAreaView, KeyboardAvoidingView, Platform } from 'react-native';
import { useAuth } from '../context/AuthContext';

export default function SupportScreen() {
  const { user } = useAuth();
  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  function handleSubmit() {
    setSubmitted(true);
    setSubject('');
    setMessage('');
  }

  return (
    <SafeAreaView className="flex-1 bg-paper">
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} className="flex-1 px-6 pt-8">
        <Text className="font-bold text-2xl text-ink">Need help?</Text>
        <Text className="text-slate mt-1 mb-6">Send us a message and we'll get back within 24 hours.</Text>

        {submitted ? (
          <View className="bg-success/10 border border-success/20 rounded-2xl p-6 items-center">
            <Text className="font-semibold text-ink mb-1">Message sent.</Text>
            <Text className="text-sm text-slate text-center">We'll reply to {email} shortly.</Text>
            <Pressable onPress={() => setSubmitted(false)} className="mt-4">
              <Text className="text-ink underline text-sm">Send another message</Text>
            </Pressable>
          </View>
        ) : (
          <>
            <Field label="Name" value={name} onChange={setName} />
            <Field label="Email" value={email} onChange={setEmail} keyboardType="email-address" />
            <Field label="Subject" value={subject} onChange={setSubject} placeholder="e.g. Payment didn't go through" />
            <Field label="Message" value={message} onChange={setMessage} multiline />

            <Pressable onPress={handleSubmit} className="bg-ink rounded-xl py-4 items-center mt-2">
              <Text className="text-paper font-semibold">Send message</Text>
            </Pressable>
          </>
        )}

        <View className="mt-8 pt-6 border-t border-ink/10">
          <Text className="text-sm text-slate">
            Prefer email? Reach us directly at <Text className="text-ink font-medium">support@preparationadda.com</Text>
          </Text>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

function Field({ label, value, onChange, placeholder, keyboardType, multiline }) {
  return (
    <View className="mb-4">
      <Text className="text-sm font-medium text-ink mb-1.5">{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChange}
        placeholder={placeholder}
        keyboardType={keyboardType}
        multiline={multiline}
        className="border border-ink/15 rounded-xl px-4 py-3 bg-white text-ink"
        style={multiline ? { minHeight: 90, textAlignVertical: 'top' } : {}}
      />
    </View>
  );
}
