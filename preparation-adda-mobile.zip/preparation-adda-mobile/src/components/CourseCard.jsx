import { View, Text, Image, Pressable } from 'react-native';
import Svg, { Path } from 'react-native-svg';

export default function CourseCard({ course, progressPercent, onPress }) {
  const hasProgress = typeof progressPercent === 'number';

  return (
    <Pressable
      onPress={onPress}
      className="bg-white rounded-2xl overflow-hidden border border-ink/10 mb-4"
      style={{ shadowColor: '#000', shadowOpacity: 0.04, shadowRadius: 6, elevation: 1 }}
    >
      <View className="flex-row">
        <View
          className="w-1.5"
          style={{
            backgroundColor: hasProgress ? '#E2E8F0' : '#1E1B4B',
            position: 'absolute',
            left: 0,
            top: 0,
            bottom: 0,
            zIndex: 1,
          }}
        />
        {hasProgress && (
          <View
            style={{
              position: 'absolute',
              left: 0,
              top: 0,
              width: 6,
              height: `${progressPercent}%`,
              backgroundColor: '#F59E0B',
              zIndex: 2,
            }}
          />
        )}
      </View>

      <Image source={{ uri: course.thumbnail }} className="w-full h-36" resizeMode="cover" />

      <View className="p-4">
        <Text className="text-xs font-semibold text-amber-dark uppercase tracking-wide mb-1">{course.category}</Text>
        <Text className="font-semibold text-ink text-base leading-snug" numberOfLines={2}>{course.title}</Text>
        <Text className="text-sm text-slate mt-1">{course.instructor}</Text>

        <View className="flex-row items-center gap-1 mt-2">
          <StarIcon filled size={13} />
          <Text className="text-sm font-medium text-ink">{course.rating}</Text>
          <Text className="text-sm text-slate-light">({course.reviewCount})</Text>
        </View>

        <View className="flex-row items-center justify-between mt-3">
          {hasProgress ? (
            <Text className="text-sm font-semibold text-ink">{progressPercent}% complete</Text>
          ) : (
            <Text className="font-semibold text-ink text-lg">₹{course.price.toLocaleString('en-IN')}</Text>
          )}
          <Text className="text-xs text-slate-light">{course.totalDuration}</Text>
        </View>
      </View>
    </Pressable>
  );
}

function StarIcon({ filled, size = 14 }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill={filled ? '#F59E0B' : 'none'} stroke="#F59E0B" strokeWidth={1.5}>
      <Path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
    </Svg>
  );
}

export { StarIcon };
