import { View, Text } from 'react-native';
import Svg, { Circle, Path } from 'react-native-svg';

// Mobile equivalent of the web app's ProgressRing.jsx — same visual
// signature (the hand-drawn-feeling progress ring), same math, just
// react-native-svg instead of plain SVG DOM elements.
export default function ProgressRing({ percent = 0, size = 44, strokeWidth = 4 }) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (percent / 100) * circumference;
  const isComplete = percent >= 100;

  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Svg width={size} height={size} style={{ position: 'absolute', transform: [{ rotate: '-90deg' }] }}>
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="#E2E8F0"
          strokeWidth={strokeWidth}
        />
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={isComplete ? '#16A34A' : '#F59E0B'}
          strokeWidth={strokeWidth}
          strokeDasharray={`${circumference} ${circumference}`}
          strokeDashoffset={offset}
          strokeLinecap="round"
        />
      </Svg>
      {isComplete ? (
        <Svg width={14} height={14} viewBox="0 0 24 24" fill="none">
          <Path d="M5 13l4 4L19 7" stroke="#16A34A" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round" />
        </Svg>
      ) : (
        <Text style={{ fontSize: 11, fontWeight: '600', color: '#1E1B4B' }}>{percent}%</Text>
      )}
    </View>
  );
}
