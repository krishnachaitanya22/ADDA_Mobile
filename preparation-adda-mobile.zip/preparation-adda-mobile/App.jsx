import 'react-native-gesture-handler';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';
import { AuthProvider, useAuth } from './src/context/AuthContext';

import CatalogScreen from './src/screens/CatalogScreen';
import LoginScreen from './src/screens/LoginScreen';
import SignupScreen from './src/screens/SignupScreen';
import CourseDetailScreen from './src/screens/CourseDetailScreen';
import DashboardScreen from './src/screens/DashboardScreen';
import AdminScreen from './src/screens/AdminScreen';
import SupportScreen from './src/screens/SupportScreen';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

// Bottom tabs for a logged-in STUDENT
function StudentTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: '#1E1B4B',
        tabBarInactiveTintColor: '#94A3B8',
        tabBarIcon: ({ color, size }) => {
          const icons = { Catalog: 'grid-outline', Dashboard: 'school-outline', Support: 'help-circle-outline' };
          return <Ionicons name={icons[route.name]} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Catalog" component={CatalogScreen} options={{ title: 'Courses' }} />
      <Tab.Screen name="Dashboard" component={DashboardScreen} options={{ title: 'My Courses' }} />
      <Tab.Screen name="Support" component={SupportScreen} options={{ title: 'Support' }} />
    </Tab.Navigator>
  );
}

// Bottom tabs for a logged-in ADMIN
function AdminTabsNav() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: '#1E1B4B',
        tabBarInactiveTintColor: '#94A3B8',
        tabBarIcon: ({ color, size }) => {
          const icons = { Catalog: 'grid-outline', Admin: 'settings-outline', Support: 'help-circle-outline' };
          return <Ionicons name={icons[route.name]} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Catalog" component={CatalogScreen} options={{ title: 'Courses' }} />
      <Tab.Screen name="Admin" component={AdminScreen} options={{ title: 'Manage' }} />
      <Tab.Screen name="Support" component={SupportScreen} options={{ title: 'Support' }} />
    </Tab.Navigator>
  );
}

// Tabs for anyone NOT logged in yet (can still browse + needs to hit Login to buy)
function GuestTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: '#1E1B4B',
        tabBarInactiveTintColor: '#94A3B8',
        tabBarIcon: ({ color, size }) => {
          const icons = { Catalog: 'grid-outline', Support: 'help-circle-outline' };
          return <Ionicons name={icons[route.name]} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Catalog" component={CatalogScreen} options={{ title: 'Courses' }} />
      <Tab.Screen name="Support" component={SupportScreen} options={{ title: 'Support' }} />
    </Tab.Navigator>
  );
}

function RootNavigator() {
  const { user, isLoading } = useAuth();

  if (isLoading) return null; // could show a splash/loading screen here

  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      {user?.role === 'admin' ? (
        <Stack.Screen name="AdminTabs" component={AdminTabsNav} />
      ) : user?.role === 'student' ? (
        <Stack.Screen name="MainTabs" component={StudentTabs} />
      ) : (
        <Stack.Screen name="GuestTabs" component={GuestTabs} />
      )}
      <Stack.Screen name="Login" component={LoginScreen} options={{ presentation: 'modal' }} />
      <Stack.Screen name="Signup" component={SignupScreen} options={{ presentation: 'modal' }} />
      <Stack.Screen
        name="CourseDetail"
        component={CourseDetailScreen}
        options={{ headerShown: true, title: '', headerTransparent: false }}
      />
    </Stack.Navigator>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <StatusBar style="dark" />
      <NavigationContainer>
        <RootNavigator />
      </NavigationContainer>
    </AuthProvider>
  );
}
