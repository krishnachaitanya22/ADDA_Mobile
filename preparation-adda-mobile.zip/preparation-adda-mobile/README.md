# Preparation Adda — Mobile (Android + iOS)

React Native app built with Expo. Shares the same business-logic pattern as
the web app (`student-lms/`) — same mock data, same API function names, same
`USE_MOCK_DATA` switch. Only the UI layer is rebuilt with native components.

**Status:** Fully wired to mock data, same as the web demo. Browse courses,
log in, view course details, watch preview lessons, "buy" a course, track
progress, leave reviews, and manage courses as admin — all working right now.

## Fastest way to see it running (no Android Studio needed)

1. Install the **Expo Go** app on your Android phone from the Play Store
   (or iPhone from the App Store)
2. On your computer:
   ```bash
   cd preparation-adda-mobile
   npm install
   npx expo start
   ```
3. A QR code appears in your terminal. Scan it with the **Expo Go** app
   (Android: scan directly in the Expo Go app; iPhone: use the Camera app)
4. The app loads on your phone in seconds, live-reloading as you edit code

This is genuinely how most React Native development happens day-to-day —
no emulator, no Android Studio, just your actual phone over the same WiFi.

## Demo accounts

Same as the web app:

| Role    | Email                        | Password    |
|---------|-------------------------------|-------------|
| Student | aditi@example.com            | password123 |
| Admin   | admin@preparationadda.com    | admin123    |

## Building a real installable APK (for the business demo / Play Store)

When you're ready to share an actual installable file instead of using
Expo Go:

```bash
npm install -g eas-cli
eas login
eas build --platform android --profile preview
```

This builds in Expo's cloud (free tier available) and gives you a
downloadable `.apk` link — no local Android Studio setup required. For a
Play Store submission later, use `--profile production` instead, which
builds an `.aab` file.

## Project structure

```
App.jsx              <- navigation setup (bottom tabs + stack), role-aware
src/
  api/                <- SAME PATTERN AS WEB APP. See below.
    config.js         <- USE_MOCK_DATA switch, AsyncStorage instead of localStorage
    mockData.js       <- identical fixtures to the web app
    auth.js           <- same logic as web, async-aware
    courses.js        <- copied verbatim from web (no platform-specific code)
    enrollments.js    <- copied verbatim from web
    feedback.js       <- copied verbatim from web
    payments.js       <- uses Razorpay's React Native SDK instead of Web Checkout
  components/         <- ProgressRing (react-native-svg), CourseCard
  context/            <- AuthContext, same shape as web
  screens/            <- the 5 screens, native-component versions of the web pages
```

## What's genuinely shared with the web app vs. rebuilt

| File | Status |
|---|---|
| `mockData.js` | Identical — copied directly |
| `courses.js`, `enrollments.js`, `feedback.js` | Identical — copied directly, zero platform code |
| `auth.js`, `config.js` | Same logic, adapted for `AsyncStorage` (async-only on mobile) |
| `payments.js` | Same shape/function names, but uses Razorpay's native SDK instead of Web Checkout — see comments in the file |
| All UI (`screens/`, `components/`) | Rebuilt with React Native components (`View`/`Text`/`Pressable` instead of `div`/`span`/`button`), same design tokens (colors, fonts) via NativeWind |

## Connecting to your real backend

Identical approach to the web app:

1. Open `src/api/config.js`
2. Set `USE_MOCK_DATA = false`
3. Set `BASE_URL` to your deployed backend's URL

No screen needs to change. Same REST endpoints as documented in the web
app's README power both clients.

## Payments on mobile

`src/api/payments.js` has the real flow commented out and ready to
uncomment once you're ready:

```bash
npm install react-native-razorpay
```

The backend endpoints (`/payments/create-order`, `/payments/verify`) are
**identical** to the web app — same Razorpay account, same server-side
signature verification. Only the client SDK differs between web and mobile.

## Video playback on mobile

Currently uses `react-native-webview` to embed the same YouTube iframe URL
as the web app. When you migrate to Bunny.net/Cloudflare Stream later
(per the original plan), swap the WebView for their player SDK — same
migration path as the web app, same point of change (`CourseDetailScreen.jsx`).
