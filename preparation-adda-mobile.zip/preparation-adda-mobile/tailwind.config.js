/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./App.js', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#1E1B4B',
        amber: { DEFAULT: '#F59E0B', dark: '#B45309' },
        paper: '#FAFAF7',
        slate: { DEFAULT: '#475569', light: '#94A3B8' },
        success: '#16A34A',
        coral: '#F43F5E',
      },
    },
  },
  plugins: [],
};
